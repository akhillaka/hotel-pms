import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { 
  DollarSign, TrendingUp, TrendingDown, PlusCircle, Search, Filter, 
  Printer, ArrowUpRight, ArrowDownRight, User, Calendar, Check, AlertTriangle,
  Lock, Unlock, Wallet, CreditCard, Smartphone, History, BarChart3, Activity, List
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function MoneyManager({ user, permission }) {
  // Data state
  const [transactions, setTransactions] = useState([]);
  const [activeRegister, setActiveRegister] = useState(null);
  const [shiftHistory, setShiftHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Tab/Filter state for Master Ledger
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [dateFilter, setDateFilter] = useState('All Time'); // 'Today', 'This Week', 'This Month', 'All Time'

  // Register open/close form state
  const [showOpenModal, setShowOpenModal] = useState(false);
  const [openCash, setOpenCash] = useState('');
  const [openNotes, setOpenNotes] = useState('');

  const [showCloseModal, setShowCloseModal] = useState(false);
  const [actualCash, setActualCash] = useState('');
  const [closeNotes, setCloseNotes] = useState('');

  // Dialog logging form state
  const [showLogModal, setShowLogModal] = useState(false);
  const [formType, setFormType] = useState('Income');
  const [formCategory, setFormCategory] = useState('Room Tariff');
  const [formAmount, setFormAmount] = useState('');
  const [formDesc, setFormDesc] = useState('');

  const categories = [
    'Room Tariff', 'Food & Beverage', 'Maintenance', 'Utilities', 'Salaries', 'Inventory', 'Other'
  ];

  const fetchData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('pms_token');
      const headers = { Authorization: `Bearer ${token}` };

      const [txnsRes, currentRes, historyRes] = await Promise.all([
        axios.get('/api/transactions', { headers }),
        axios.get('/api/ledger/current', { headers }),
        axios.get('/api/ledger/history', { headers })
      ]);

      setTransactions(txnsRes.data);
      setActiveRegister(currentRes.data);
      setShiftHistory(historyRes.data);
    } catch (err) {
      toast.error('Failed to load ledger data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenRegister = async (e) => {
    e.preventDefault();
    if (permission === 'read') return toast.error('Permission Denied');
    try {
      const token = localStorage.getItem('pms_token');
      const res = await axios.post('/api/ledger/open', {
        opening_cash: parseFloat(openCash) || 0,
        notes: openNotes
      }, { headers: { Authorization: `Bearer ${token}` } });
      
      toast.success('Shift Register Opened successfully!');
      setActiveRegister(res.data);
      setShowOpenModal(false);
      setOpenCash(''); setOpenNotes('');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to open register');
    }
  };

  const handleCloseRegister = async (e) => {
    e.preventDefault();
    if (permission === 'read') return toast.error('Permission Denied');
    try {
      const token = localStorage.getItem('pms_token');
      const res = await axios.post('/api/ledger/close', {
        actual_cash: parseFloat(actualCash) || 0,
        notes: closeNotes
      }, { headers: { Authorization: `Bearer ${token}` } });
      
      toast.success(`Shift Register Closed! Discrepancy: ₹${res.data.cash_discrepancy}`);
      setActiveRegister(null);
      setShiftHistory([res.data, ...shiftHistory]);
      setShowCloseModal(false);
      setActualCash(''); setCloseNotes('');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to close register');
    }
  };

  const handleLogTransaction = async (e) => {
    e.preventDefault();
    if (permission === 'read') return toast.error('Permission Denied');
    if (!formAmount || !formDesc) return toast.error('Please fill in all fields');

    try {
      const token = localStorage.getItem('pms_token');
      const res = await axios.post('/api/transactions', {
        type: formType,
        amount: parseFloat(formAmount),
        category: formCategory,
        description: formDesc
      }, { headers: { Authorization: `Bearer ${token}` } });

      toast.success(`Transaction logged successfully`);
      setTransactions(prev => [res.data, ...prev]);
      setShowLogModal(false);
      
      setFormAmount(''); setFormDesc('');
      setFormCategory('Room Tariff'); setFormType('Income');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to post transaction');
    }
  };

  // Helper dates
  const today = new Date();
  today.setHours(0,0,0,0);
  const thisWeek = new Date(today);
  thisWeek.setDate(today.getDate() - today.getDay());
  const thisMonth = new Date(today.getFullYear(), today.getMonth(), 1);

  // Today's Aggregate Collections (Regardless of Shift)
  const todaysTxns = transactions.filter(t => new Date(t.created_at) >= today);
  const todayCash = todaysTxns.filter(t => t.type === 'Income' && t.description.toLowerCase().includes('cash')).reduce((s,t) => s+t.amount, 0)
                  + todaysTxns.filter(t => t.type === 'Income' && !t.description.toLowerCase().includes('upi') && !t.description.toLowerCase().includes('card') && !t.description.toLowerCase().includes('cash')).reduce((s,t) => s+t.amount, 0); // fallback to cash if unknown
  const todayCard = todaysTxns.filter(t => t.type === 'Income' && t.description.toLowerCase().includes('card')).reduce((s,t) => s+t.amount, 0);
  const todayUpi = todaysTxns.filter(t => t.type === 'Income' && t.description.toLowerCase().includes('upi')).reduce((s,t) => s+t.amount, 0);
  const todayExpenses = todaysTxns.filter(t => t.type === 'Expense').reduce((s,t) => s+t.amount, 0);
  const todayTotalIncome = todayCash + todayCard + todayUpi;

  // Transaction tab filters
  const filteredTxns = useMemo(() => transactions.filter(t => {
    const dDate = new Date(t.created_at);
    let matchesDate = true;
    if (dateFilter === 'Today') matchesDate = dDate >= today;
    if (dateFilter === 'This Week') matchesDate = dDate >= thisWeek;
    if (dateFilter === 'This Month') matchesDate = dDate >= thisMonth;

    const matchesSearch = 
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.created_by.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'All' || t.type === typeFilter;
    const matchesCategory = categoryFilter === 'All' || t.category === categoryFilter;
    
    return matchesDate && matchesSearch && matchesType && matchesCategory;
  }), [transactions, searchQuery, typeFilter, categoryFilter, dateFilter]);

  // Analytics logic (Last 7 days)
  const miniChartData = useMemo(() => {
    const days = [];
    for(let i=6; i>=0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
      days.push({ key: dateStr, amount: 0, dateObj: d });
    }
    
    transactions.filter(t => t.type === 'Income').forEach(t => {
      const tDate = new Date(t.created_at);
      const match = days.find(d => d.dateObj.getDate() === tDate.getDate() && d.dateObj.getMonth() === tDate.getMonth());
      if (match) match.amount += t.amount;
    });
    
    return days;
  }, [transactions]);

  if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}><div className="spinner" style={{ margin: '0 auto 16px' }}/>Loading dashboard...</div>;

  const maxChartVal = Math.max(...miniChartData.map(d => d.amount), 1);

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div className="page-header no-print">
        <div>
          <h1 className="page-title">Financial Dashboard</h1>
          <p className="page-subtitle">Track your property's cash flow, shift registers, and daily collections</p>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          {permission === 'edit' && (
            <button onClick={() => setShowLogModal(true)} className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <PlusCircle size={16} /> Log Transaction
            </button>
          )}
          <button onClick={() => window.print()} className="btn btn-default" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Printer size={16} /> Print
          </button>
        </div>
      </div>

      {/* TOP ROW: TODAY'S METRICS */}
      <h2 style={{ fontSize: '1.05rem', fontWeight: 800, marginTop: '-8px' }}>Today's Collections Overview</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
        <div className="stat-tile" style={{ background: 'var(--surface)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>Total Income</span>
            <DollarSign size={16} className="text-brand" />
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, fontFamily: 'var(--font-mono)', marginTop: '8px' }}>₹{todayTotalIncome.toFixed(2)}</div>
        </div>
        <div className="stat-tile" style={{ background: '#f0fdf4', borderColor: '#bbf7d0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.75rem', color: '#166534', fontWeight: 700, textTransform: 'uppercase' }}>Cash Volume</span>
            <Wallet size={16} color="#166534" />
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#166534', fontFamily: 'var(--font-mono)', marginTop: '8px' }}>₹{todayCash.toFixed(2)}</div>
        </div>
        <div className="stat-tile" style={{ background: '#eff6ff', borderColor: '#bfdbfe' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.75rem', color: '#1e40af', fontWeight: 700, textTransform: 'uppercase' }}>Card & Gateway</span>
            <CreditCard size={16} color="#1e40af" />
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#1e40af', fontFamily: 'var(--font-mono)', marginTop: '8px' }}>₹{todayCard.toFixed(2)}</div>
        </div>
        <div className="stat-tile" style={{ background: '#faf5ff', borderColor: '#e9d5ff' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 700, textTransform: 'uppercase' }}>UPI Volume</span>
            <Smartphone size={16} color="#6b21a8" />
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#6b21a8', fontFamily: 'var(--font-mono)', marginTop: '8px' }}>₹{todayUpi.toFixed(2)}</div>
        </div>
        <div className="stat-tile" style={{ background: '#fef2f2', borderColor: '#fecaca' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.75rem', color: '#991b1b', fontWeight: 700, textTransform: 'uppercase' }}>Expenses</span>
            <TrendingDown size={16} color="#991b1b" />
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#991b1b', fontFamily: 'var(--font-mono)', marginTop: '8px' }}>₹{todayExpenses.toFixed(2)}</div>
        </div>
      </div>

      {/* MIDDLE ROW: CHART & SHIFT CONTROL */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px', alignItems: 'stretch' }}>
        {/* Revenue Chart */}
        <div className="glass-panel" style={{ display: 'flex', flexDirection: 'column' }}>
          <h3 style={{ fontSize: '1rem', fontWeight: 800, marginBottom: '20px' }}>Revenue Last 7 Days</h3>
          <div style={{ flex: 1, display: 'flex', gap: '12px', alignItems: 'flex-end', minHeight: '180px' }}>
            {miniChartData.map(d => (
              <div key={d.key} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '100%', maxWidth: '30px', background: 'var(--brand-gradient)', height: `${(d.amount/maxChartVal)*100}%`, borderRadius: '4px 4px 0 0', minHeight: '4px' }} title={`₹${d.amount.toFixed(2)}`} />
                <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>{d.key}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Shift Control Panel */}
        <div className="glass-panel" style={{ background: activeRegister ? '#f0fdf4' : 'var(--surface)', borderColor: activeRegister ? '#bbf7d0' : 'var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 800, color: activeRegister ? '#166534' : 'inherit' }}>Shift Register</h3>
            {activeRegister ? (
              <span className="badge badge-green animate-pulse">● OPEN</span>
            ) : (
              <span className="badge" style={{ background: '#e2e8f0', color: '#64748b' }}>CLOSED</span>
            )}
          </div>
          
          {activeRegister ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ fontSize: '0.8rem', color: '#166534' }}>
                <p>Opened by <strong>{activeRegister.opened_by}</strong></p>
                <p>{new Date(activeRegister.opened_at).toLocaleTimeString('en-IN')}</p>
              </div>
              <div style={{ background: '#fff', padding: '12px', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
                <span style={{ fontSize: '0.7rem', color: '#166534', fontWeight: 'bold' }}>OPENING CASH</span>
                <div style={{ fontSize: '1.2rem', fontFamily: 'var(--font-mono)', fontWeight: 800, color: '#166534' }}>₹{activeRegister.opening_cash.toFixed(2)}</div>
              </div>
              {permission === 'edit' && (
                <button onClick={() => setShowCloseModal(true)} className="btn btn-danger" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px', width: '100%', marginTop: 'auto' }}>
                  <Lock size={16} /> Close & Audit
                </button>
              )}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', textAlign: 'center', gap: '12px', paddingBottom: '20px' }}>
              <Lock size={32} className="text-muted" />
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Open a register to start tracking shift shortages and overages securely.</p>
              {permission === 'edit' && (
                <button onClick={() => setShowOpenModal(true)} className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Unlock size={16} /> Open Shift
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* BOTTOM SECTION: MASTER LEDGER */}
      <h2 style={{ fontSize: '1.05rem', fontWeight: 800, marginTop: '8px' }}>Master Transaction Ledger</h2>
      <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div className="filter-bar no-print">
          <div className="search-wrap" style={{ flex: '1' }}>
            <Search className="search-icon" size={16} />
            <input 
              type="text" placeholder="Search by Transaction ID or description..." 
              className="glass-input" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <select className="glass-input" style={{ padding: '6px 12px', fontSize: '0.75rem', height: '34px', width: '130px' }} value={dateFilter} onChange={(e) => setDateFilter(e.target.value)}>
              <option value="All Time">All Time</option>
              <option value="Today">Today</option>
              <option value="This Week">This Week</option>
              <option value="This Month">This Month</option>
            </select>
            <div style={{ display: 'flex', background: 'var(--surface-3)', borderRadius: '8px', padding: '3px', border: '1px solid var(--border)' }}>
              <button onClick={() => setTypeFilter('All')} className={`filter-pill ${typeFilter === 'All' ? 'active' : ''}`} style={{ fontSize: '0.75rem', padding: '6px 12px' }}>All</button>
              <button onClick={() => setTypeFilter('Income')} className={`filter-pill ${typeFilter === 'Income' ? 'active' : ''}`} style={{ fontSize: '0.75rem', padding: '6px 12px' }}>Incomes</button>
              <button onClick={() => setTypeFilter('Expense')} className={`filter-pill ${typeFilter === 'Expense' ? 'active' : ''}`} style={{ fontSize: '0.75rem', padding: '6px 12px' }}>Expenses</button>
            </div>
            <select className="glass-input" style={{ padding: '6px 12px', fontSize: '0.75rem', height: '34px', width: '150px' }} value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
              <option value="All">All Categories</option>
              {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '0px', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1.5px solid #cbd5e1', textAlign: 'left', color: 'var(--text-muted)' }}>
                <th style={{ padding: '12px 16px' }}>TRANSACTION ID</th>
                <th style={{ padding: '12px 16px' }}>DATE & TIME</th>
                <th style={{ padding: '12px 16px' }}>TYPE</th>
                <th style={{ padding: '12px 16px' }}>CATEGORY</th>
                <th style={{ padding: '12px 16px' }}>DESCRIPTION</th>
                <th style={{ padding: '12px 16px', textAlign: 'right' }}>AMOUNT</th>
                <th style={{ padding: '12px 16px' }}>OPERATOR</th>
              </tr>
            </thead>
            <tbody>
              {filteredTxns.map((txn) => (
                <tr 
                  key={txn.id} 
                  style={{ 
                    borderBottom: '1px solid #e2e8f0',
                    cursor: txn.reservation_id ? 'pointer' : 'default'
                  }} 
                  className="hover-highlight"
                  onClick={() => {
                    if (txn.reservation_id && onViewFolio) {
                      onViewFolio({ id: txn.reservation_id });
                    }
                  }}
                  title={txn.reservation_id ? "Click to view folio" : ""}
                >
                  <td style={{ padding: '12px 16px', fontFamily: 'var(--font-mono)', fontWeight: 'bold', color: txn.reservation_id ? 'var(--brand-600)' : 'var(--brand-700)', textDecoration: txn.reservation_id ? 'underline' : 'none' }}>{txn.id}</td>
                  <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>{new Date(txn.created_at).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</td>
                  <td style={{ padding: '12px 16px' }}><span className={`badge ${txn.type === 'Income' ? 'badge-green' : 'badge-danger'}`} style={{ fontSize: '0.7rem' }}>{txn.type}</span></td>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{txn.category}</td>
                  <td style={{ padding: '12px 16px', maxWidth: '280px', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>{txn.description}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 'bold', color: txn.type === 'Income' ? '#166534' : '#991b1b' }}>{txn.type === 'Income' ? '+' : '-'}₹{txn.amount.toFixed(2)}</td>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{txn.created_by}</td>
                </tr>
              ))}
              {filteredTxns.length === 0 && (
                <tr><td colSpan="7" style={{ padding: '48px', textAlign: 'center', color: 'var(--text-faint)' }}>No transactions found for these filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* OPEN REGISTER MODAL */}
      {showOpenModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(15,23,42,0.5)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '400px', padding: '24px', background: '#fff' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}><Unlock size={20} className="text-brand" /> Open Shift Register</h3>
            <form onSubmit={handleOpenRegister} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="label">Opening Cash in Drawer (₹)</label>
                <input type="number" step="0.01" className="glass-input" value={openCash} onChange={e => setOpenCash(e.target.value)} required placeholder="e.g. 5000" />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Verify physical cash before opening.</span>
              </div>
              <div>
                <label className="label">Notes (Optional)</label>
                <textarea className="glass-input" value={openNotes} onChange={e => setOpenNotes(e.target.value)} placeholder="Any starting notes..." rows="2" />
              </div>
              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '8px' }}>
                <button type="button" onClick={() => setShowOpenModal(false)} className="btn btn-default">Cancel</button>
                <button type="submit" className="btn btn-primary">Open Register</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CLOSE REGISTER MODAL */}
      {showCloseModal && activeRegister && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(15,23,42,0.5)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '400px', padding: '24px', background: '#fff' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}><Lock size={20} className="text-danger" /> Close & Audit Register</h3>
            <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', marginBottom: '16px', border: '1px solid #e2e8f0', fontSize: '0.85rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}><span>Opening Cash:</span> <strong>₹{activeRegister.opening_cash.toFixed(2)}</strong></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}><span>Expected Drawer Cash:</span> <span>Will be computed automatically.</span></div>
            </div>
            <form onSubmit={handleCloseRegister} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="label">Actual Counted Cash in Drawer (₹)</label>
                <input type="number" step="0.01" className="glass-input" value={actualCash} onChange={e => setActualCash(e.target.value)} required placeholder="Enter exact physical cash" />
              </div>
              <div>
                <label className="label">Closing Notes / Discrepancy Reason</label>
                <textarea className="glass-input" value={closeNotes} onChange={e => setCloseNotes(e.target.value)} placeholder="Required if there is a shortage or overage..." rows="2" />
              </div>
              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '8px' }}>
                <button type="button" onClick={() => setShowCloseModal(false)} className="btn btn-default">Cancel</button>
                <button type="submit" className="btn btn-danger">Confirm Closure</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LOG TRANSACTION MODAL */}
      {showLogModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(4px)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <div className="glass-panel" style={{ width: '450px', padding: '24px', background: '#fff' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 'bold', borderBottom: '1px solid var(--border)', paddingBottom: '12px', marginBottom: '16px' }}>Log Cash Flow Transaction</h3>
            <form onSubmit={handleLogTransaction} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="label">Flow Type</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  <button type="button" onClick={() => { setFormType('Income'); setFormCategory('Room Tariff'); }} className={`btn ${formType === 'Income' ? 'btn-primary' : 'btn-default'}`}>📈 INCOME</button>
                  <button type="button" onClick={() => { setFormType('Expense'); setFormCategory('Utilities'); }} className={`btn ${formType === 'Expense' ? 'btn-danger' : 'btn-default'}`}>📉 EXPENSE</button>
                </div>
              </div>
              <div>
                <label className="label">Category</label>
                <select className="glass-input" value={formCategory} onChange={e => setFormCategory(e.target.value)}>
                  {formType === 'Income' ? (
                    <>
                      <option value="Room Tariff">Room Tariff / Bookings</option>
                      <option value="Food & Beverage">Food & Beverage Sales</option>
                      <option value="Other">Other Ancillary Incomes</option>
                    </>
                  ) : (
                    <>
                      <option value="Utilities">Electricity / Water / Internet</option>
                      <option value="Maintenance">Room & Facility Maintenance</option>
                      <option value="Salaries">Payroll / Staff Salaries</option>
                      <option value="Inventory">Linen & Room Prep restock</option>
                      <option value="Other">Miscellaneous Expenses</option>
                    </>
                  )}
                </select>
              </div>
              <div>
                <label className="label">Cash Amount (₹)</label>
                <input type="number" min="0.01" step="0.01" className="glass-input" value={formAmount} onChange={e => setFormAmount(e.target.value)} required />
              </div>
              <div>
                <label className="label">Details / Remarks</label>
                <textarea className="glass-input" value={formDesc} onChange={e => setFormDesc(e.target.value)} rows="3" required />
              </div>
              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '8px' }}>
                <button type="button" onClick={() => setShowLogModal(false)} className="btn btn-default">Cancel</button>
                <button type="submit" className="btn btn-primary">Commit Entry</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
